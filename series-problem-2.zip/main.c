/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//series problem//
//find the value of n: 1/2 + 3/4 +.....n//
#include <stdio.h>

int main()
{
    int i,n;
    double s=0.0;
    printf("Enter the values of n:");
    scanf("%d",&n);
    for(i=1;i<=n;i+=2)
    {
        s+=(double)i/(i+1);
    }
    printf("%.6f",s);
    return 0;
}
